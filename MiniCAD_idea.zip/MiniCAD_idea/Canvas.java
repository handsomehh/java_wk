package MiniCAD_idea;

import javax.swing.*;
import java.awt.*;

public class Canvas extends JPanel {
    MyController myController;
    Mylistener mylistener;
    public Canvas(MyController col,Mylistener lis){
        myController = col;
        mylistener = lis;
        this.setBackground(new Color(186, 186, 191, 255));
        this.addMouseListener(mylistener);
        this.addMouseMotionListener(mylistener);

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        myController.paintAll(g);
    }
}
