package MiniCAD_idea;

import javax.swing.*;
import java.awt.*;

public class Layout_Ctrl extends JFrame {
    static final int LINE = 0;
    static final int CIRCLE = 1;
    static final int RECTANGLE = 2;
    static final int TEXT = 3;
    static final int COLOR = 4;

    static final int SAVE = 10;
    static final int OPEN = 11;
    private JPanel menuPanel;
    Toolkit tk = Toolkit.getDefaultToolkit();
    Dimension screenSize = tk.getScreenSize();
    Mylistener mylistener;
    MyController myController;

    public Canvas canvas;
    public Layout_Ctrl(Mylistener mylistener, MyController myController) {
        this.myController = myController;
        this.mylistener = mylistener;
        this.canvas = new Canvas(this.myController, this.mylistener);
    }

    public void start() {
        /* 画主页 */
        this.setTitle("mini CAD");
        this.setMinimumSize(new Dimension(800, 500));
        System.out.println(screenSize);
        this.setSize(new Dimension((int) screenSize.getWidth() / 3 * 2, (int) screenSize.getHeight() / 3 * 2));
        System.out.println(this.getSize());
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        add_Components();

        this.setVisible(true);
    }

    private void add_Components() {
        /* 导航栏设置 */
        JMenuBar menubar = new JMenuBar();
        JMenu fileMenu = new JMenu("选项");
        menubar.add(fileMenu);
        JMenuItem saveItem = new JMenuItem("保存");
        saveItem.setActionCommand(SAVE+"");
        JMenuItem loadItem = new JMenuItem("打开新的");
        loadItem.setActionCommand(OPEN+"");
        saveItem.addActionListener(mylistener);
        loadItem.addActionListener(mylistener);
        saveItem.addKeyListener(mylistener);
        loadItem.addKeyListener(mylistener);
        fileMenu.add(saveItem);
        fileMenu.add(loadItem);
        this.setJMenuBar(menubar);
        /* 控制面板设置 */
        this.menuPanel = new JPanel(new GridLayout(1,6));
        this.menuPanel
                .setPreferredSize(
                        new Dimension((int) (screenSize.getWidth() / 6), (int) (screenSize.getHeight() / 12)));
        /* 增加按钮 */
        this.menuPanel.setBorder(BorderFactory.createTitledBorder("控制面板"));

        //line
        JButton line = new JButton();// 调整大小
        line.setBounds(0, 0, 35, 35);
        line.setToolTipText("Draw a line"); // 添加说明
        line.setIcon(new ImageIcon(new ImageIcon("./icon/line.png").getImage().
                getScaledInstance(line.getWidth(),
                line.getHeight(), Image.SCALE_SMOOTH)));
        line.setActionCommand(LINE + "");
        line.addActionListener(mylistener);

        //cirecle
        JButton circle = new JButton();// 调整大小
        circle.setBounds(0, 0, 35, 35);
        circle.setToolTipText("Draw a circle"); // 添加说明
        circle.setIcon(new ImageIcon(new ImageIcon("./icon/circle.png").getImage().getScaledInstance(circle.getWidth(),
                circle.getHeight(), Image.SCALE_SMOOTH)));
        circle.setActionCommand(CIRCLE + "");
        circle.addActionListener(mylistener);
        //rectangle
        JButton rectangle = new JButton();// 调整大小
        rectangle.setBounds(0, 0, 35, 35);
        rectangle.setToolTipText("Draw a rectangle"); // 添加说明
        rectangle.setIcon(new ImageIcon(new ImageIcon("./icon/rectangle.png").getImage().getScaledInstance(rectangle.getWidth(),
                rectangle.getHeight(), Image.SCALE_SMOOTH)));
        rectangle.setActionCommand(RECTANGLE + "");
        rectangle.addActionListener(mylistener);

        //text
        JButton text = new JButton();// 调整大小
        text.setBounds(0, 0, 35, 35);
        text.setToolTipText("Draw a text"); // 添加说明
        text.setIcon(new ImageIcon(new ImageIcon("./icon/text.png").getImage().getScaledInstance(text.getWidth(),
                text.getHeight(), Image.SCALE_SMOOTH)));
        text.setActionCommand(TEXT + "");
        text.addActionListener(mylistener);

        //color
        JButton color = new JButton();// 调整大小
        color.setBounds(0, 0, 35, 35);
        color.setToolTipText("change the color"); // 添加说明
        color.setIcon(new ImageIcon(new ImageIcon("./icon/color.png").getImage().getScaledInstance(color.getWidth(),
                color.getHeight(), Image.SCALE_SMOOTH)));
        color.setActionCommand(COLOR + "");
        color.addActionListener(mylistener);
        /*canvas*/


        line.addKeyListener(mylistener);
        text.addKeyListener(mylistener);
        circle.addKeyListener(mylistener);
        rectangle.addKeyListener(mylistener);
        color.addKeyListener(mylistener);

        this.menuPanel.add(line);
        this.menuPanel.add(circle);
        this.menuPanel.add(rectangle);
        this.menuPanel.add(text);
        this.menuPanel.add(color);

        this.add(this.menuPanel, BorderLayout.NORTH);
        canvas.addKeyListener(mylistener);
        canvas.requestFocus();
        System.out.println();
        mylistener.addc(canvas);
        this.add(canvas, BorderLayout.CENTER);
    }
}
