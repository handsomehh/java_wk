package MiniCAD_idea;

public class Main {

    public static void main(String[] args) {
        MyController myController = new MyController();
        Mylistener mylistener = new Mylistener(myController);
        Layout_Ctrl layout_ctrl = new Layout_Ctrl(mylistener,myController);
        layout_ctrl.start();
        myController.Settg(layout_ctrl.canvas.getGraphics());
        mylistener.addc(layout_ctrl.canvas);
    }
}
