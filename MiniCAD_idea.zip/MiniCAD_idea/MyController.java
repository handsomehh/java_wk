package MiniCAD_idea;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class MyController {
    ArrayList<Shape> shapes = new ArrayList<>();
    Color mycolor = Color.BLACK;
    private static Graphics2D tg;

    static final int LINE = 0;
    static final int CIRCLE = 1;
    static final int RECTANGLE = 2;
    static final int TEXT = 3;

    public static Shape PraseShape(String readStr) throws ShapeException {
        String [] arr = readStr.split(",");

        if(arr.length==10||arr.length==11){
            try{
                switch (arr.length){
                    case 10:
                    {
                        if(Integer.parseInt(arr[0])>=3||Integer.parseInt(arr[0])<0){
                            throw new ShapeException();
                        }else{
                            int type = Integer.parseInt(arr[0]);
                            int r = Integer.parseInt(arr[1]);
                            int g = Integer.parseInt(arr[2]);
                            int b = Integer.parseInt(arr[3]);
                            int a = Integer.parseInt(arr[4]);
                            Color color = new Color(r,g,b,a);
                            float w = Float.parseFloat(arr[5]);
                            double x1 = Double.parseDouble(arr[6]);
                            double y1 = Double.parseDouble(arr[7]);
                            double x2 = Double.parseDouble(arr[8]);
                            double y2 = Double.parseDouble(arr[9]);
                            return new Shape(type,tg,color,w,x1,y1,x2,y2,null);
                        }
                    }
                    case 11:{
                        if(Integer.parseInt(arr[0])!=3){
                            throw new ShapeException();
                        }else{
                            int type = Integer.parseInt(arr[0]);
                            int r = Integer.parseInt(arr[1]);
                            int g = Integer.parseInt(arr[2]);
                            int b = Integer.parseInt(arr[3]);
                            int a = Integer.parseInt(arr[4]);
                            Color color = new Color(r,g,b,a);
                            float w = Float.parseFloat(arr[5]);
                            String text = arr[6];
                            double x1 = Double.parseDouble(arr[7]);
                            double y1 = Double.parseDouble(arr[8]);
                            double x2 = Double.parseDouble(arr[9]);
                            double y2 = Double.parseDouble(arr[10]);
                            return new Shape(type,tg,color,w,x1,y1,x2,y2,text);
                        }
                    }
                }
            }catch (NumberFormatException e){
                e.printStackTrace();
                throw new ShapeException();
            }catch (IllegalArgumentException e){
//                e.printStackTrace();
                throw new ShapeException();
            }

        }else{
            throw new ShapeException();
        }
        return null;
    }

    public void loadt(ArrayList<Shape> temp) {
        shapes.clear();
        shapes = temp;
        for(Shape i : shapes){
            i.setG(tg);
        }
    }

    public void paintAll(Graphics g) {
        for(Shape i : shapes){
            i.draw(g);
        }
    }
    public void Settg(Graphics in){
        tg = (Graphics2D) in;
    }
    public Shape create_shape(int mymode, double x, double y, double x1, double y1,String text) {
        Shape shape = new Shape(mymode,tg,mycolor,1.0f,x, y, x1, y1, text);
        shapes.add(shape);
        return shape;
    }

    public void change_shape(Shape shape,int mode,Point2D p2) {
        shape.set(mode,p2);
    }

    public Shape Selectone(Point2D cur_point) {
        Shape temp = null;
        for(Shape shape : shapes){
            if(shape.t_bound.contains(cur_point.getX(),cur_point.getY())){
                temp = shape;
                break;
            }
        }
        return temp;
    }

    public void move_shape(Shape shape,double dx,double dy) {
        shape.move(dx, dy);
    }


    public void enlarge(Shape shape) {
        shape.enlarge();
    }

    public void shrink(Shape shape) {
        shape.shrink();
    }

    public void coarsen(Shape shape) {
        shape.coarsen();
    }

    public void thin(Shape shape) {
        shape.thin();
    }

    public void setColor(Color m_color) {
        mycolor = m_color;
    }

    public String GetShapes() {
        StringBuilder con = new StringBuilder();
        for(Shape i : shapes){
            con.append(i.GetShapes());
            con.append("\n");
        }
        return con.toString();
    }

    public void delete(Shape shape) {
        shapes.remove(shape);
    }
}

class Shape {
    //线条为0 矩形为1 圆形为2 text为3
    public static final int LINE = 0;
    public static final int RECTANGLE = 1;
    public static final int CIRCLE = 2;
    public static final int TEXT = 3;
    private Color t_color;
    private Rectangle2D rect;
    private Ellipse2D circle;
    private Line2D line;
    private String text;
    private FontMetrics t_fontMetrics;
    private Font t_font;
    Rectangle2D t_bound;
    private Graphics2D tg;
    boolean isChosed = false;
    private Stroke dash = new BasicStroke(1.0f,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,3.5f,new float[]{15,10,},0f);
    public int t_type;
    private float t_weight;
    private Point2D p1;

    Shape(int type, Graphics2D g, Color color, float weight, double x1, double y1, double x2, double y2, String text){
        t_type = type;
        tg = g;
        t_color = color;
        t_weight = weight;
        t_font = new Font("Serif", Font.PLAIN, 20);
        p1 = new Point2D.Double(x1, y1);
        switch (type) {
            case LINE -> { //直线
                line = new Line2D.Double(x1, y1, x2, y2);
                t_bound = line.getBounds2D();
                break;
            }
            case RECTANGLE -> {//矩形
                rect = new Rectangle((int) x1, (int) y1, (int) Math.abs(x1 - x2), (int) Math.abs(y1 - y2));
                System.out.println(rect);
                t_bound = rect.getBounds2D();
                break;
            }
            case CIRCLE -> {//圆形
                circle = new Ellipse2D.Double(x1, y1, Math.abs(x1 - x2), Math.abs(y1 - y2));
                t_bound = circle.getBounds2D();
                break;
            }
            case TEXT -> {//文字
                this.text = text;
                System.out.println(this.text);
                tg.setFont(t_font);
                t_bound = new Rectangle2D.Double(p1.getX(), p1.getY(), Math.abs(x1 - x2), Math.abs(y1 - y2));
                t_font = t_font.deriveFont(1);
                t_fontMetrics = tg.getFontMetrics(t_font);
                while (true) {
                    if (t_fontMetrics.stringWidth(text) <= t_bound.getWidth() && t_fontMetrics.getAscent() <= t_bound.getHeight()) {
                        t_font = t_font.deriveFont(t_font.getSize2D() + 1);
                        t_fontMetrics = tg.getFontMetrics(t_font);
                    } else {
                        t_font = t_font.deriveFont(t_font.getSize2D() - 1);
                        t_fontMetrics = tg.getFontMetrics(t_font);
                        break;
                    }
                }
                break;
            }
            default -> {
                break;
            }
        }
        System.out.println("初始化:"+type + "x1:"+x1 + "y1:" + y1 + " " + "x2:" + x2 + "y2:" + y2);
    }
    public void draw(Graphics g){
        Graphics2D g2d = tg;
        tg = (Graphics2D)g;
        tg.setColor(t_color);
        tg.setStroke(new BasicStroke(t_weight));
        switch (t_type) {
            case LINE -> {
                tg.draw(line);
                break;
            }
            case RECTANGLE -> {
                tg.draw(rect);
                break;
            }
            case CIRCLE -> {
                tg.draw(circle);
                break;
            }
            case TEXT -> {
                tg.setFont(t_font);
                t_fontMetrics = tg.getFontMetrics(t_font);
                t_bound = new Rectangle2D.Double(p1.getX(), p1.getY(), t_fontMetrics.stringWidth(text), t_fontMetrics.getAscent());
                tg.drawString(text, (int) (t_bound.getX()), (int) (t_bound.getY() + t_bound.getHeight()));
                break;
            }
            default -> {
                break;
            }
        }
        if(isChosed){
            tg.setColor(Color.BLACK);
            tg.setStroke(dash);
            Rectangle2D dash_bound = new Rectangle2D.Double(t_bound.getX()-2,t_bound.getY()-2,t_bound.getWidth()+4,t_bound.getHeight()+4);
            tg.draw(dash_bound);
        }
        tg = g2d;
    }

    public void set(int mode,Point2D p2) {
        switch (mode) {
            case LINE -> {
                line.setLine(p1, p2);
                t_bound = line.getBounds2D();
                break;
            }
            case RECTANGLE -> {
                rect.setFrameFromDiagonal(p1, p2);
                t_bound = rect.getBounds2D();
                break;
            }
            case CIRCLE -> {
                circle.setFrameFromDiagonal(p1, p2);
                t_bound = circle.getBounds2D();
                break;
            }
            case TEXT -> {
                if (p2.getX() < p1.getX() || p2.getY() < p1.getY()) break;
                t_bound.setFrameFromDiagonal(p1, p2);
                t_font = t_font.deriveFont(1);
                t_fontMetrics = tg.getFontMetrics(t_font);
                while (true) {
                    if (t_fontMetrics.stringWidth(text) <= t_bound.getWidth() && t_fontMetrics.getAscent() <= t_bound.getHeight()) {
                        t_font = t_font.deriveFont(t_font.getSize2D() + 1);
                        t_fontMetrics = tg.getFontMetrics(t_font);
                    } else {
                        t_font = t_font.deriveFont(t_font.getSize2D() - 1);
                        t_fontMetrics = tg.getFontMetrics(t_font);
                        break;
                    }
                }
                break;
            }
        }
    }
    public void Setg(Graphics2D g){
        tg = g;
    }

    public void move(double dx,double dy) {
        switch (t_type) {
            case LINE -> {
                p1.setLocation(line.getP1().getX() + dx, line.getP1().getY() + dy);
                line.setLine(line.getP1().getX() + dx, line.getP1().getY() + dy, line.getP2().getX() + dx, line.getP2().getY() + dy);
                t_bound = line.getBounds2D();
                break;
            }
            case RECTANGLE -> {
                p1.setLocation(rect.getX() + dx, rect.getY() + dy);
                rect.setFrameFromDiagonal(rect.getX() + dx, rect.getY() + dy, rect.getX() + dx + rect.getWidth(), rect.getY() + dy + rect.getHeight());
                t_bound = rect.getBounds2D();
                break;
            }
            case CIRCLE -> {
                p1.setLocation(circle.getX() + dx, circle.getY() + dy);
                circle.setFrameFromDiagonal(circle.getX() + dx, circle.getY() + dy, circle.getX() + dx + circle.getWidth(), circle.getY() + dy + circle.getHeight());
                t_bound = circle.getBounds2D();
                break;
            }
            case TEXT -> {
                p1.setLocation(t_bound.getX() + dx, t_bound.getY() + dy);
                System.out.println(p1);
                t_fontMetrics = tg.getFontMetrics(t_font);
                t_bound = new Rectangle2D.Double(t_bound.getX() + dx, t_bound.getY() + dy, t_fontMetrics.stringWidth(text), t_fontMetrics.getAscent());
                tg.drawString(text, (int) (t_bound.getX()), (int) (t_bound.getY() + t_bound.getHeight()));
                break;
            }
        }
    }

    public void enlarge() {
        switch (t_type) {
            case LINE -> {
                double x1 = line.getP1().getX(), x2 = line.getP2().getX(), y1 = line.getP1().getY(), y2 = line.getP2().getY();
                double rate = 1;
                p1.setLocation(x1, y1);
                line.setLine(x1, y1, x2 + (y2 - y1) / (x2 - x1) * rate, y2 + (y2 - y1) / (x2 - x1) * rate);
                t_bound = line.getBounds2D();
                break;
            }
            case RECTANGLE -> {
                p1.setLocation(rect.getX() - 1, rect.getY() - 1);
                rect.setFrameFromDiagonal(rect.getX() - 1, rect.getY() - 1, rect.getX() + 1 + rect.getWidth(), rect.getY() + 1 + rect.getHeight());
                t_bound = rect.getBounds2D();
                break;
            }
            case CIRCLE -> {
                p1.setLocation(circle.getX(), circle.getY());
                circle.setFrameFromDiagonal(circle.getX() - 1, circle.getY() - 1, circle.getX() + 1 + circle.getWidth(), circle.getY() + 1 + circle.getHeight());
                t_bound = circle.getBounds2D();
                break;
            }
            case TEXT -> {
                p1.setLocation(t_bound.getX(), t_bound.getY());
                if (t_font.getSize2D() > 300) break;
                t_font = t_font.deriveFont(t_font.getSize2D() + 2);
                t_fontMetrics = tg.getFontMetrics(t_font);
                System.out.println(t_font.getSize2D());
                t_bound = new Rectangle2D.Double(p1.getX(), p1.getY(), t_fontMetrics.stringWidth(text), t_fontMetrics.getAscent());
                tg.drawString(text, (int) (t_bound.getX()), (int) (t_bound.getY() + t_bound.getHeight()));
                break;
            }
        }
    }

    public void shrink() {
        switch (t_type) {
            case LINE -> {
                double x1 = line.getP1().getX(), x2 = line.getP2().getX(), y1 = line.getP1().getY(), y2 = line.getP2().getY();
                double rate = 1;
                if (Math.abs(x1 - x2) <= 2 || Math.abs(y1 - y2) <= 2 || Math.abs(Math.sqrt((y1 - y2) * (y1 - y2) + (x1 - x2) * (x1 - x2))) <= 5
                        || x2 == x1 || y2 == y1 || (x2 - (y2 - y1) / (x2 - x1) * rate - x1) * (x2 - x1) <= 0 || (y2 - (y2 - y1) / (x2 - x1) * rate) * (y2 - y1) <= 0)
                    break;
                p1.setLocation(x1, y1);
                line.setLine(x1, y1, x2 - (y2 - y1) / (x2 - x1) * rate, y2 - (y2 - y1) / (x2 - x1) * rate);
                t_bound = line.getBounds2D();
                break;
            }
            case RECTANGLE -> {
                if (rect.getWidth() <= 1 || rect.getHeight() <= 1) break;
                p1.setLocation(rect.getX() + 1, rect.getY() + 1);

                rect.setFrameFromDiagonal(rect.getX() + 1, rect.getY() + 1, rect.getX() - 1 + rect.getWidth(), rect.getY() - 1 + rect.getHeight());
                t_bound = rect.getBounds2D();
                break;
            }
            case CIRCLE -> {
                if (circle.getWidth() <= 1 || circle.getHeight() <= 1) break;
                p1.setLocation(circle.getX() + 1, circle.getY() + 1);
                circle.setFrameFromDiagonal(circle.getX() + 1, circle.getY() + 1, circle.getX() - 1 + circle.getWidth(), circle.getY() - 1 + circle.getHeight());
                t_bound = circle.getBounds2D();
                break;
            }
            case TEXT -> {
                p1.setLocation(t_bound.getX(), t_bound.getY());
                if (t_font.getSize2D() < 10) break;
                t_font = t_font.deriveFont(t_font.getSize2D() - 2);
                t_fontMetrics = tg.getFontMetrics(t_font);
                System.out.println(t_font.getSize2D());
                t_bound = new Rectangle2D.Double(p1.getX(), p1.getY(), t_fontMetrics.stringWidth(text), t_fontMetrics.getAscent());
                tg.drawString(text, (int) (t_bound.getX()), (int) (t_bound.getY() + t_bound.getHeight()));
                break;
            }
        }
    }

    public void coarsen() {
        if(t_weight<=6)t_weight+=0.1;
    }

    public void thin() {
        if(t_weight>=0.2)t_weight-=0.1;
    }

    public void setColor(Color m_color) {
        t_color = m_color;
    }

    public String  GetShapes() {
        StringBuilder txt = new StringBuilder();
        txt.append(String.valueOf(t_type)).append(",");
        txt.append(t_color.getRed()).append(",").append(t_color.getGreen()).append(",").append(t_color.getBlue()).append(",").append(t_color.getAlpha()).append(",");
        txt.append(String.valueOf(t_weight)).append(",");
        switch (t_type) {
            case LINE -> {
                txt.append(line.getP1().getX()).append(",").append(line.getP1().getY()).append(",").append(line.getP2().getX()).append(",").append(line.getP2().getY());
                break;
            }
            case CIRCLE -> {
                Point2D p2 = new Point2D.Double(circle.getBounds2D().getX(), circle.getBounds2D().getY());
                Point2D p3 = new Point2D.Double(circle.getBounds2D().getX() + circle.getBounds2D().getWidth(), circle.getBounds2D().getY() + circle.getBounds2D().getHeight());
                txt.append(p2.getX()).append(",").append(p2.getY()).append(",").append(p3.getX()).append(",").append(p3.getY());
                break;
            }
            case RECTANGLE -> {
                Point2D p2 = new Point2D.Double(rect.getX(), rect.getY());
                Point2D p3 = new Point2D.Double(rect.getX() + rect.getWidth(), rect.getY() + rect.getHeight());
                txt.append(p2.getX()).append(",").append(p2.getY()).append(",").append(p3.getX()).append(",").append(p3.getY());
                break;
            }
            case TEXT -> {
                txt.append(text).append(",");
                txt.append(t_bound.getX()).append(",").append(t_bound.getY()).append(",");
                txt.append(t_bound.getX() + t_bound.getWidth()).append(",");
                txt.append(t_bound.getY() + t_bound.getHeight());
                break;
            }
        }
        return txt.toString();
    }

    public void setG(Graphics2D tg) {
        this.tg = tg;
    }
}
class ShapeException extends Exception{
    public ShapeException() {
    }

    public ShapeException(String message) {
        super(message);
    }
}
