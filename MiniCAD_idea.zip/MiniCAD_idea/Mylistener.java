package MiniCAD_idea;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.io.*;
import java.util.ArrayList;

public class Mylistener implements ActionListener, MouseListener, MouseMotionListener,KeyListener {
    static final int LINE = 0;
    static final int CIRCLE = 1;
    static final int RECTANGLE = 2;
    static final int TEXT = 3;
    static final int SELECTED = 4;
    static final int FREE = 5;
    static final int COLOR = 6;

    static final int SAVE = 10;
    static final int OPEN = 11;
    int mymode = FREE;
    private static Color m_color = Color.BLACK;
    private Point2D cur_point = new Point2D.Double();

    private Shape shape = null;
    private MyController myController;
    private String text;
    int select_type;
    Canvas canvas;
    public Mylistener(MyController myController){
        this.myController = myController;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        switch (Integer.parseInt(e.getActionCommand())){
            case LINE:{
                System.out.println("line");
                mymode = LINE;
                if(shape!=null)shape.isChosed = false;
                shape = null;
                break;
            }
            case CIRCLE:{
                System.out.println("circle");
                mymode = CIRCLE;
                if(shape!=null)shape.isChosed = false;
                shape = null;
                break;
            }
            case RECTANGLE:{
                System.out.println("rectangle");
                mymode = RECTANGLE;
                if(shape!=null)shape.isChosed = false;
                shape = null;
                break;
            }
            case TEXT:{
                System.out.println("text");
                mymode = TEXT;
                if(shape!=null)shape.isChosed = false;
                shape = null;
                text = JOptionPane.showInputDialog("Please input the text:");
                System.out.println(text);
                if(text==null)mymode=FREE;
                break;
            }
            case COLOR-2:{
                m_color = JColorChooser.showDialog((Component) source, "Choose Color", Color.BLACK);
                if(shape != null) {
                    shape.setColor(m_color);
                    canvas.repaint();
                }
                else{
                    myController.setColor(m_color);
                }
                break;
            }
            case SAVE:{
                System.out.println("save");
                File saveFile = new File("cad.txt");//保存为jpg文件
                JFileChooser chooser = new JFileChooser();
                chooser.setCurrentDirectory(new File("./"));
                chooser.setSelectedFile(saveFile);
                int rval = chooser.showSaveDialog(canvas);
                if (rval == JFileChooser.APPROVE_OPTION) {
                    saveFile = chooser.getSelectedFile();
                    try {
                        String content = myController.GetShapes();
                        FileOutputStream fileOutputStream = new FileOutputStream(saveFile);
                        fileOutputStream.write(content.getBytes("utf-8"));
                    } catch (IOException ex){
                        System.out.println("can not save drawing");
                        ex.printStackTrace();
                    }
                }
                break;
            }
            case OPEN:{
                JFileChooser chooser = new JFileChooser();
                chooser.setCurrentDirectory(new File("./"));
                FileNameExtensionFilter filter = new FileNameExtensionFilter(null,"txt");
                chooser.setFileFilter(filter);
                int rval = chooser.showOpenDialog(canvas);
                File openFile = null;
                if (rval == JFileChooser.APPROVE_OPTION){
                    openFile = chooser.getSelectedFile();
                    try{
                        BufferedReader reader = new BufferedReader(new FileReader(openFile));
                        String readStr;
                        ArrayList<Shape> temp  = new ArrayList<>();
                        while ((readStr = reader.readLine()) != null) {
                            System.out.println(readStr);
                            temp.add(MyController.PraseShape(readStr));
                        }
                        reader.close();
                        myController.loadt(temp);
                    } catch (IOException ex){
                        System.out.println("can not open");
                    }catch (ShapeException ex){
                        System.out.println("File format error");
                    }
                }
                System.out.println("load a picture");
                canvas.repaint();
                break;
            }
            default:{
                System.out.println("In click button : no match type!");
                break;
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        Component canvas = e.getComponent();
        cur_point.setLocation(e.getX(), e.getY());
        if(canvas instanceof Canvas) {
            System.out.println("canvas pressed at: " + cur_point);
            switch (mymode){
                case LINE :{
                }
                case CIRCLE:{
                }
                case TEXT:{

                }
                case RECTANGLE: {
                    shape = myController.create_shape(mymode,cur_point.getX(), cur_point.getY(), cur_point.getX(), cur_point.getY(),text);
                    shape.isChosed = true;
                    canvas.repaint();
                    break;
                }
                case FREE:{
                    shape = myController.Selectone(cur_point);
                    if(shape==null) {
                        System.out.println("空");
                    }else{
                        System.out.println("选择成功");
                        shape.isChosed = true;
                        mymode = SELECTED;

                    }
                    canvas.repaint();
                    break;
                }
                case SELECTED:{
                    Shape temp;
                    temp = myController.Selectone(cur_point);
                    if(temp==null) {
                        System.out.println("s空");
                        shape.isChosed=false;
                        mymode = FREE;
                    }else{
                        System.out.println("选择成功");
                        shape.isChosed = false;
                        shape = temp;
                        shape.isChosed = true;

                    }
                    canvas.repaint();
                    break;
                }
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        Component canvas = e.getComponent();
        cur_point.setLocation(e.getX(), e.getY());
        if(canvas instanceof Canvas) {
            System.out.println("canvas release at: " + cur_point);
            switch (mymode){
                case LINE :{
                }
                case CIRCLE:{
                }
                case TEXT:{

                }
                case RECTANGLE: {
                    if(shape==null)break;
                    shape.isChosed = false;
                    shape = null;
                    mymode=FREE;
                    text="";
                    canvas.repaint();
                     break;
                }
                case FREE:{
                    if(shape==null)break;
                    shape.isChosed = false;
                    shape = null;
                    text="";
                    canvas.repaint();
                    break;
                }


            }

        }

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        Component canvas = e.getComponent();
        double dx = cur_point.getX()-e.getX();
        double dy  = cur_point.getY() - e.getY();
        cur_point.setLocation(e.getX(), e.getY());
        if(canvas instanceof Canvas) {
            System.out.println("canvas pressed at: " + cur_point);
            switch (mymode){
                case LINE :{
                }
                case CIRCLE:{
                }
                case TEXT:{

                }
                case RECTANGLE: {
                    if(shape==null)break;
                    myController.change_shape(shape,mymode,cur_point);
                    canvas.repaint();
                    break;
                }
                case SELECTED:{
                    myController.move_shape(shape,-dx,-dy);
                    canvas.repaint();
                    break;
                }

            }
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }


    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(mymode!=SELECTED)return;
        switch (e.getKeyChar()) {
            case '+' -> {
                System.out.println("+");
                myController.enlarge(shape);
                break;
            }
            case '-' -> {
                System.out.println("-");
                myController.shrink(shape);
                break;
            }
            case '<' -> {
                System.out.println("<");
                myController.coarsen(shape);
                break;
            }
            case '>' -> {
                System.out.println(">");
                myController.thin(shape);
                break;
            }
        }
        if(e.getKeyCode()==127){
            System.out.println("delete");
            shape.isChosed=false;
            myController.delete(shape);
            mymode=FREE;
        }
        canvas.repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public void addc(Canvas canvas) {
        this.canvas = canvas;
    }
}
