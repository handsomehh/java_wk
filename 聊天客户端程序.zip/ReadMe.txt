编译运行服务器：
javac ChatServe.java
java ChatServe

编译运行GUI客户端：
javac Client_view.java
java Client_view


压力测试：（WSL/linux/Git bash/虚拟机等任何支持shell的方式都可以）
sh test.sh 

也可以直接运行jar包：
java -jar Server
java -jar Client

**需要强调的是**，一定确保在测试客户端代码所在的文件夹下有名为t的文件夹：

    |-test.sh
    |-ChatClient.java
    |-t
      |-0.txt
      |-1.txt
      |-…………

总体的文件结构：
    |-src
    |  |-XXX（源文件）
    |  
    |-jar
    |  |-xxx（jar包）
    |
    |-test
      |-test.sh
      |-ChatClient.java
      |-t
        |-0.txt
        |-1.txt
        |-…………