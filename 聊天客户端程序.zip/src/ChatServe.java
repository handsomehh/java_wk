import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ChatServe {
    private static final int port = 5385;
    private static ArrayList<Client> clients = new ArrayList<Client>();
    private static Msg_List msg_lists = new Msg_List();

    public static void main(String[] args) throws IOException {
        ServerSocket sockets = new ServerSocket(port);
        System.out.println("开始监听，监听端口为"+port);
        msg_lists.start();
        while (true){
            try {
                Socket client =  sockets.accept();
                Client newclient = new Client(client,msg_lists,clients);
                synchronized (clients){
                    clients.add(newclient);
                    newclient.start();
                }
            }catch (IOException e){
                System.out.println("unexcepted happen");
                e.printStackTrace();
            }
        }
    }
    public static ArrayList<Client> GetClients(){
            return clients;
    }
}
