import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Client extends Thread {
    Socket client;
    Msg_List msg_lists;
    String name = new String();
    ArrayList<Client> clients;

    public Client(Socket client, Msg_List msg_lists, ArrayList<Client> clients) {
        this.client = client;
        this.msg_lists = msg_lists;
        this.clients = clients;
    }

    @Override
    public synchronized void start() {
        super.start();
    }

    boolean DuplicateName(String name) {
        synchronized (clients){
            for (Client i : clients) {
                if (i.name.equals(name))
                    return true;
            }
        }
        return false;
    }

    @Override
    public void run() {
        try {
            super.run();
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(client.getOutputStream())),
                    true);
            while (true) {
                String temp;
                temp = in.readLine();
                System.out.println("name:" + temp);
                if (temp.equals("") || DuplicateName(temp)) {
                    out.println("名字不合法或已有重复姓名，请重新输入");
                } else {
                    name = temp;
                    break;
                }
            }

            out.println("Welcome to miniChat, " + name);
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            String sendMsg = "[" + formatter.format(new Date()) + "]" + name + ": I entered chat.";
            msg_lists.AddMsg(sendMsg);
            synchronized (msg_lists) {
                msg_lists.notifyAll();
            }
            System.out.println(sendMsg);
            while (true) {
                sendMsg = in.readLine();
                formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                if (sendMsg.equals("___END___")) {
                    sendMsg = "[" + formatter.format(new Date()) + "]" + name + ": goodbye!";
                    msg_lists.AddMsg(sendMsg);
                    synchronized (clients) {
                        clients.remove(this);
                    }
                    synchronized (msg_lists) {
                        msg_lists.notifyAll();
                    }
                    client.close();
                    break;
                }
                sendMsg = "[" + formatter.format(new Date()) + "]" + name + ": " + sendMsg;
                msg_lists.AddMsg(sendMsg);
                System.out.println(sendMsg);
                synchronized (msg_lists) {
                    msg_lists.notifyAll();
                }
            }
        } catch (IOException e) {
            synchronized (clients) {
                clients.remove(this);
            }

            try {
                client.close();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
            msg_lists.AddMsg(name + " is exit");
            System.out.println(name + " is exit");
            synchronized (msg_lists) {
                msg_lists.notifyAll();
            }
        }
    }

    public void sendMessage(String msg) {
        try {
            new PrintWriter(new BufferedWriter(new OutputStreamWriter(client.getOutputStream())), true).println(msg);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
