import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

class Login extends JFrame {
    public Login(){
        JTextField text1,text2;
        setResizable(false);
        this.setTitle("登录");
        this.setLayout(new GridLayout(3, 1));
        this.setSize(250, 200);
        this.setLocation(550, 200);
        JPanel panel= new JPanel();
        JPanel panel1= new JPanel();
        JPanel panel2= new JPanel();
        JButton b1 =new JButton("登录");
        panel.add(b1);
        JLabel lable1 = new JLabel("Name");
        JLabel lable2 = new JLabel("Host");
        text1 =new JTextField(13);
        text2 =new JTextField(13);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("点击登录");
                String name = text1.getText();
                String host = text2.getText();
                System.out.println("name:"+name+" host:"+host);
                if(Client_view.Permit(name,host)){
                    Client_view.TurnView();
                }
            }
        });
        panel1.add(lable1);
        panel1.add(text1);
        panel2.add(lable2);
        panel2.add(text2);
        this.add(panel1);
        this.add(panel2);
        this.add(panel,BorderLayout.SOUTH);
//        this.setVisible(true);
    }
}

class Chat extends JFrame {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    final int WIDTH = 420;
    final int HEIGHT = 700;
    
    JButton SendBtn = new JButton("发送");
    JButton ClearBtn = new JButton("清屏");
    JButton ExitBtn = new JButton("退出");
    
    JTextArea inputContext = new JTextArea();

    // 创建聊天消息框
    public JTextArea ChatContext = new JTextArea();

    // 创建聊天消息框的滚动窗
    JScrollPane Chatroll = new JScrollPane(ChatContext);

    // 创建当前在线列表的滚动窗
    public Chat(){
        setTitle("聊天室");
        setSize(WIDTH, HEIGHT);
        setResizable(false);
        setLayout(null);
        SendBtn.setBounds(20, 600, 100, 60);
        ClearBtn.setBounds(140, 600, 100, 60);
        ExitBtn.setBounds(260, 600, 100, 60);
        SendBtn.setFont(new Font("宋体", Font.BOLD, 18));
        ClearBtn.setFont(new Font("宋体", Font.BOLD, 18));
        ExitBtn.setFont(new Font("宋体", Font.BOLD, 18));
        this.add(SendBtn);
        this.add(ClearBtn);
        this.add(ExitBtn);

        inputContext.setBounds(20, 460, 360, 120);
        inputContext.setFont(new Font("楷体", Font.BOLD, 16));
        this.add(inputContext);

        ChatContext.setLineWrap(true);
        ChatContext.setEditable(false);
        ChatContext.setFont(new Font("楷体", Font.BOLD, 16));

        // 设置滚动窗的水平滚动条属性:不出现
//        Chatroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 设置滚动窗的垂直滚动条属性:需要时自动出现
        Chatroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        // 设置滚动窗大小和位置
        Chatroll.setBounds(20, 20, 360, 400);
        // 添加聊天窗口的滚动窗
        this.add(Chatroll);

        // 设置滚动窗的水平滚动条属性:不出现
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        // 获取本机屏幕横向分辨率
        int w = Toolkit.getDefaultToolkit().getScreenSize().width;
        // 获取本机屏幕纵向分辨率
        int h = Toolkit.getDefaultToolkit().getScreenSize().height;
        // 将窗口置中
        this.setLocation((w - this.WIDTH) / 2, (h - this.HEIGHT) / 2);
        ClearBtn.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent event) {
                        ChatContext.setText("");
                    }
                });
        ExitBtn.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent event) {
                        try {
                            Client_view.printThread.SendMsg("___END___");
                            System.exit(0);
                        } catch (Exception e) {
                        }
                    }
                });
        SendBtn.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent event) {

                        ChatContext.setCaretPosition(ChatContext.getDocument().getLength());
                        try {
                            Client_view.printThread.SendMsg(inputContext.getText());
                            inputContext.setText("");
                        } catch (Exception e) {
                        } finally {
                        }
                    }
                });
    }
}

public class Client_view {
    static final int PORT = 5385;
    static Login login = new Login();
    static Chat chat = new Chat();
    public static void main(String[] args) {
        login.setVisible(true);
    }
    static Socket socket;
    static InetAddress addr = null;
    static PrintThread printThread = new PrintThread();
    public static boolean Permit(String name,String host) {
        try {
            addr = InetAddress.getByName(host);
            socket = new Socket(addr, PORT);
            System.out.println("socket connected");
            PrintWriter writer =new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            BufferedReader reader =  new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer.println(name);
            String temp = reader.readLine();
            System.out.println(temp);
            if(temp.equals("名字不合法或已有重复姓名，请重新输入")){
                JOptionPane.showMessageDialog(null,"名字重复");
                socket.close();
                return false;
            }else{
                JOptionPane.showMessageDialog(null,"Welcome to miniChat!");
            }
            new ReadinThread(socket).start();
            printThread.setSocket(socket);
            return true;
        } catch (UnknownHostException e) {
            JOptionPane.showMessageDialog(null,"未找到host");
            return false;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "连接失败");
            return false;
        }
    }

    public static void TurnView() {
        login.setVisible(false);
        chat.setVisible(true);
    }
}
class PrintThread {
    private PrintWriter writer;
    private Socket socket;

    public void setSocket(Socket socket) {
        try {
            this.writer =new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.socket = socket;
    }
    public void SendMsg(String msg){
        if (socket.isClosed())
            return;
        writer.println(msg);
    }
}

class ReadinThread extends Thread {
    private BufferedReader reader;
    private Socket socket;
    public ReadinThread(Socket socket) {
        try {
            this.reader =  new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        this.socket = socket;
    }
    public void run() {
        // dead loop
        while (true) {
            try {
                if (socket.isClosed())
                    break;
                String received = reader.readLine();
                System.out.println(received);
                Client_view.chat.ChatContext.append(received+"\n");
                if (received.equals("--END--")) {
                    System.out.println("closing...");
                    socket.close();
                }
            } catch (IOException e) {
                System.out.println(e);
                System.exit(-1);
            }
        }
    }
}