import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Msg_List extends Thread{
//    ArrayList<String> msg = new ArrayList<>();
    CopyOnWriteArrayList<String> msg = new CopyOnWriteArrayList<>();
    Lock l = new ReentrantLock();
    public synchronized void  AddMsg(String sendMsg) {
        l.lock();
        msg.add(sendMsg);
        l.unlock();
    }

    @Override
    public void run(){
        super.run();

        while(true){
            String line = null;
            synchronized (this) {
                if (msg.isEmpty()) {
                    try {
                        this.wait();
                    } catch (InterruptedException e) {
                    }
                }
                if (!msg.isEmpty()) {
                    l.lock();
                    line = msg.get(0);
                    msg.remove(0);
                    l.unlock();
                }
            }
            if (line != null) {
                synchronized (ChatServe.GetClients()) {
                    for (Client c : ChatServe.GetClients()) {
                        c.sendMessage(line);
                    }
                }
            }
        }
    }
}
