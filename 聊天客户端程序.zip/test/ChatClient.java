//ZJU zituitui 2021 11 26
//i love you jyf

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;
import java.util.jar.Attributes.Name;

import javax.print.attribute.standard.MediaSize.NA;

//the ChatClient
public class ChatClient {
    public static final int PORT = 5385;
    Scanner scanner = new Scanner(System.in);

    private BufferedReader reader;
    private PrintWriter writer;
    private Socket socket;
    static String Na;

    public ChatClient(Socket socket) throws IOException {
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
        this.socket = socket;
    }

    public void start() {
        new ReadinThread(reader, socket).start();
        new PrintThread(writer, socket).start();
    }

    public static void main(String[] args) throws IOException {
        File file = new File("./ttt.txt");
        FileWriter fw = null;
        PrintWriter pw = null;
        try {
            // 如果文件存在，则追加内容；如果文件不存在，则创建文件
            fw = new FileWriter(file, true);
            pw = new PrintWriter(fw);
            pw.println("11111");
            pw.flush();
            try {
                fw.flush();
                pw.close();
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        InetAddress addr = null;
        // InetAddress addr = InetAddress.getByName(null);
        // System.out.println("Input your targeting server address");
        // System.out.println("Input \"local\" to indicate localhost");
        System.out.println(args[0]);
        // Scanner sc = new Scanner(System.in);
        String host = "local";
        if (host.equals("local"))
            addr = InetAddress.getByName(null);
        else
            addr = InetAddress.getByName(host);
//        System.out.println("Targeting Server addr: " + addr);
        Socket socket = new Socket(addr, PORT);
//        System.out.println("socket connected");

        ChatClient client = new ChatClient(socket);
        Na = args[0];
        client.start();
    }

}

// the thread aiming to read message in
class ReadinThread extends Thread {
    private BufferedReader reader;
    private Socket socket;

    public ReadinThread(BufferedReader reader, Socket socket) {
        this.reader = reader;
        this.socket = socket;
    }

    public void run() {
        // dead loop
        File file = new File("./t/" + ChatClient.Na + ".txt");
        FileWriter fw = null;
        PrintWriter pw = null;
        try {
            // 如果文件存在，则追加内容；如果文件不存在，则创建文件
            fw = new FileWriter(file);
            pw = new PrintWriter(fw);
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (true) {
            try {
                if (socket.isClosed())
                    break;
                String received = reader.readLine();
//                System.out.println(received);
                pw.println(received);
                pw.flush();
                try {
                    fw.flush();
                    // pw.close();
                    // fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                // System.out.println(received);
                if (received.equals("--END--")) {
                    System.out.println("closing...");
                    socket.close();
                }
            } catch (IOException e) {

                System.out.println(e);
                System.exit(-1);
            }

        }
    }
}

// the thread aiming to give out message
class PrintThread extends Thread {
    private PrintWriter writer;
    private Socket socket;

    public PrintThread(PrintWriter writer, Socket socket) {
        this.writer = writer;
        this.socket = socket;
    }

    public void run() {
        // Scanner scanner = new Scanner(System.in);
        // dead loop
        int i = 0;
        try{
            sleep(10000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        while (true) {
            if (i <= 10000) {
                i++;
            } else {
                try {
                    synchronized (this){
                        this.wait();

                    }

                }catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
            // read next line from console
            if (socket.isClosed())
                break;
            String str = ChatClient.Na + i;
            // give this message to server
            writer.println(str);
//            try {
//                // sleep(1);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }

        }
    }
}
