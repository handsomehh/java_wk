javac ChatClient.java
for((i=0;i<100;i++))
do
    java ChatClient $i &
done